--[[**********************************
*
*	Multi Theft Auto - Admin Panel
*
*	client\widgets\admin_editor.lua
*
*	Original File by lil_Toady
*
**************************************]]
function nothing()
end
